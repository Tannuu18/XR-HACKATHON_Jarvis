# Jarvis Track 3 entrypoint

Requires Python 3.10+ only; no pip packages.

From this src directory run:

```sh
python main.py /path/to/imu0/data.csv ../estimated_trajectory.txt --metadata ../metadata.json
```

EuRoC headers are detected. Headerless files need `--column-order gyro-accel` or `accel-gyro`. Nanoseconds, m/s^2 and rad/s are defaults. Run `python main.py --help` for options.

The supplied trajectory and metadata are a synthetic demonstration, not an organizer evaluation. Replace them with a run on the supplied evaluation CSV. Full source, documentation and limitations: https://github.com/Tannuu18/XR-HACKATHON_Jarvis
